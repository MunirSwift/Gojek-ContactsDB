//
//  JContact.swift
//  Contacts
//
//  Created by Rydus on 24/07/2019.
//  Copyright © 2019 GoJek. All rights reserved.
//

import Foundation

struct JContact: Decodable {
    let id: Int?
    let firstName: String?
    let lastName: String?
    let profilePic: String?
    let favorite: Bool?
    let url: String?
    
    var fullName: String {
        if firstName == nil && lastName == nil {
            return ""
        } else if firstName == nil {
            return lastName ?? ""
        } else if lastName == nil {
            return firstName ?? ""
        } else {
            return (firstName ?? "")  + " " + (lastName ?? "")
        }
    }
}
