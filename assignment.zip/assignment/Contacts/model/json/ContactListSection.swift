//
//  ContactListSection.swift
//  Contacts
//
//  Created by Rydus on 26/07/2019.
//  Copyright © 2019 GoJek. All rights reserved.
//

import Foundation

struct ContactListSection {
    let sectionTitle: String
    let contacts: [JContact]
}

