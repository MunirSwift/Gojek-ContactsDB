//
//  SearchParser.swift
//  Gojek
//
//  Created by Rydus on 25/06/2019.
//  Copyright © 2019 Rydus. All rights reserved.
//

import UIKit
import SwiftyJSON

class SearchParser {
    
    //  MARK:   High order function to filter result from model
    static func getByName(keyword:String, model:[JContact])->[JContact] {
        if !model.isEmpty {
            let j = model.filter({ (json) -> Bool in
                return json.fullName.lowercased().hasPrefix(keyword.lowercased()) }) as [JContact]
            return j
        }
        else {
            return []
        }
    }
}
