//
//  HttpMgr.swift
//  QSMobileTest
//
//  Created by Rydus on 18/05/2019.
//  Copyright © 2019 Rydus. All rights reserved.
//

import UIKit
import Alamofire
import APESuperHUD
import SwiftyJSON

//  MARK: Http Manager
//  SingleTon Design Pattern to access globally from anywhere via shared instance without to create class instance.
final class HttpMgr {
    
    static var shared = HttpMgr()
    
    func put(url:String, params:[String: AnyObject], completion: @escaping (_ result: Data)->()) {
        DispatchQueue.main.async() {
            //  Add Hud
            APESuperHUD.show(style: .loadingIndicator(type: .standard), title: nil, message: "Please wait...")
        }
        
        var request = URLRequest(url: URL(string: url)!)
        request.httpMethod = HTTPMethod.put.rawValue
        request.setValue("application/json; charset=UTF-8", forHTTPHeaderField: "Content-Type")
        request.httpBody = try! JSONSerialization.data(withJSONObject: params, options: [])
        
        Alamofire.request(request).responseJSON { response in
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1, execute: {
                APESuperHUD.dismissAll(animated: true)
            })
            
            switch response.result {
            case .success:
                if let data = response.data {
                    completion(data)
                }
                break
            case .failure(let error):
                Common.Log(str: error.localizedDescription)
                break
            }
        }
    }
    
    func post(url:String, params:[String: AnyObject], completion: @escaping (_ result: Data)->()) {
        
        DispatchQueue.main.async() {
            //  Add Hud
            APESuperHUD.show(style: .loadingIndicator(type: .standard), title: nil, message: "Please wait...")
        }
        
        /*Alamofire.request(url, method: .post, parameters: params, encoding: URLEncoding.default).responseJSON { response in
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1, execute: {
                APESuperHUD.dismissAll(animated: true)
            })
            
            switch response.result {
            case .success:
                if let data = response.data {
                    completion(data)
                }
            case .failure(let error):
                Common.Log(str: error.localizedDescription)
            }
        }*/
        
        var request = URLRequest(url: URL.init(string: url)!)
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpMethod = "POST"
        request.httpBody = try! JSONSerialization.data(withJSONObject: params, options: [])
        let task = URLSession.shared.dataTask(with: request) { [weak self] (data, response, error) -> Void in
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1, execute: {
                APESuperHUD.dismissAll(animated: true)
            })
            completion(data!)
        }
        task.resume()
    }
    
    //  MARK:   Post Data To The Web Server
    func postMultiPart(url:String, params:[String: AnyObject], completion: @escaping (_ result: Data)->()) {
        
        DispatchQueue.main.async() {
            //  Add Hud
            APESuperHUD.show(style: .loadingIndicator(type: .standard), title: nil, message: "Please wait...")
        }
        
        Alamofire.upload(
            multipartFormData: { multipartFormData in
                
                for (key, value) in params {
                    if key.hasPrefix("image") {
                        if let imageData = (value as! UIImage).pngData() {
                            multipartFormData.append(imageData, withName: "ufile1", fileName: "image.png", mimeType: "image/png")
                        }
                        else if let imageData = (value as! UIImage).jpegData(compressionQuality: 0.5) {
                            multipartFormData.append(imageData, withName: "ufile1", fileName: "image.jpg", mimeType: "image/jpeg")
                        }
                    }
                    else {
                        multipartFormData.append((value as AnyObject).data(using: String.Encoding.utf8.rawValue)!, withName: key)
                    }
                }
        },
            to: url,
            encodingCompletion: { encodingResult in
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1, execute: {
                    APESuperHUD.dismissAll(animated: true)
                })
                switch encodingResult {
                case .success(let upload, _, _):
                    upload.responseData { response in
                        if let data = response.data {
                            completion(data)
                        }
                    }
                    .uploadProgress { progress in // main queue by default
                            //self.img1Progress.alpha = 1.0
                            //self.img1Progress.progress = Float(progress.fractionCompleted)
                            Common.Log(str: "Upload Progress: \(progress.fractionCompleted)")
                    }
                    return
                case .failure(let error):
                    Common.Log(str: error.localizedDescription)
                    break;
                }
        })
    }
    
    //  MARK:   Get Data To The Web Server
    func get(url:String, completion: @escaping (_ result: Data)->()) {
        
        let serialQueue = DispatchQueue(label: "quickseries.mobile.test")
        serialQueue.sync {
            
            DispatchQueue.main.async() {
                //  Add Hud
                APESuperHUD.show(style: .loadingIndicator(type: .standard), title: nil, message: "Please wait...")
            }
            
            //  Requesting to server...
            Common.Log(str: url)
            Alamofire.request(url, method: .get, parameters: nil, encoding: JSONEncoding.default)
                .responseData { res in
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1, execute: {
                        APESuperHUD.dismissAll(animated: true)
                    })
                    
                    if let data = res.data {
                        //  Checking server response...
                        completion(data);
                    }
                    else {
                        Common.Log(str: "ERROR")
                    }
                }
        }
    }
}
