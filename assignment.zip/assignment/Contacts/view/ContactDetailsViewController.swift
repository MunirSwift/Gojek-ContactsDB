//
//  ContactDetailsViewController.swift
//  Contacts
//
//  Created by admin on 02/02/19.
//  Copyright © 2019 GoJek. All rights reserved.
//

import UIKit
import MessageUI
import Kingfisher

class ContactDetailsViewController: UIViewController, MFMessageComposeViewControllerDelegate, MFMailComposeViewControllerDelegate {

    var contactURL: String?
    var editContact: JContactDetail?

    @IBOutlet weak var contactPhotoView: UIImageView!
    @IBOutlet weak var contactName: UILabel!

    @IBOutlet weak var favouriteButtonImageView: UIImageView!

    @IBOutlet weak var phoneNumberLabel: UILabel!
    @IBOutlet weak var emailLabel: UILabel!

    var isContactFavourted = false
    
    //  MARK:   -   SMS Clicked
    @IBAction func smsButtonTapped(_ sender: UIButton) {
        if (MFMessageComposeViewController.canSendText()) {
            let controller = MFMessageComposeViewController()
            controller.body = "Hello."
            controller.recipients = ([phoneNumberLabel.text] as! [String])
            controller.messageComposeDelegate = self
            self.present(controller, animated: true)
        }
        else {
            Common.Log(str: "Can't send sms")
        }
    }
    
    //  MARK:   -   Call Clicked
    @IBAction func callButtonTapped(_ sender: UIButton) {
        if let url = URL(string: "tel://"+phoneNumberLabel.text!), UIApplication.shared.canOpenURL(url) {
            if #available(iOS 10, *) {
                UIApplication.shared.open(url)
            } else {
                UIApplication.shared.openURL(url)
            }
        }
    }
    
    //  MARK:   -   Email Clicked
    @IBAction func emailButtonTapped(_ sender: UIButton) {
        let mailComposeViewController = configureMailComposer()
        if MFMailComposeViewController.canSendMail(){
            self.present(mailComposeViewController, animated: true, completion: nil)
        }else{
            Common.Log(str: "Can't send email")
        }
    }

    @IBAction func favouriteButtonTapped(_ sender: UIButton) {
        
        let isContactFavouretdInvert = !isContactFavourted
        if isContactFavouretdInvert {
            favouriteButtonImageView.image = UIImage.init(named: "favourite_button_selected")
        } else {
            favouriteButtonImageView.image = UIImage.init(named: "favourite_button")
        }
        let contactId = editContact?.id ?? 0
        let url = Server.CONTACT_DETAILS_FAVORITE_URL.replacingOccurrences(of: "#id#", with: String(contactId))
        
        let params = [
            "favorite": String(isContactFavouretdInvert),
            "id":String(contactId)
            ] as [String : Any]
        HttpMgr.shared.put(url: url, params: params as [String : AnyObject]) { (data) in
            //self.fetchContactDetails()
            self.isContactFavourted = !self.isContactFavourted
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.title = "Contact Details"
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Edit", style: .done, target: self, action: #selector(EditTapped))
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        fetchContactDetails()
    }

    func fetchContactDetails() {
        HttpMgr.shared.get(url: contactURL!) { (data) in
            let decoder = JSONDecoder.init()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            
            self.editContact =  try! decoder.decode(JContactDetail.self, from: data)
            
            DispatchQueue.main.async {
                self.reloadData()
            }
        }
    }

    //  MARK:   -   Navigation bar right button 'Edit'
    @objc func EditTapped() {
        let vc = self.storyboard!.instantiateViewController(withIdentifier:"ContactEditViewController") as? ContactEditViewController
        vc?.editContact = self.editContact
        self.navigationController!.pushViewController(vc!, animated: true)
    }
    
    //  MARK:   -   Mail Composer
    func configureMailComposer() -> MFMailComposeViewController{
        let mailComposeVC = MFMailComposeViewController()
        mailComposeVC.mailComposeDelegate = self
        mailComposeVC.setToRecipients([emailLabel.text!])
        mailComposeVC.setSubject("Hi")
        mailComposeVC.setMessageBody("Your text here...", isHTML: false)
        return mailComposeVC
    }
    
    //  MARK:   -   MFMail compose method
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true, completion: nil)
    }
    
    //  MARK:   -   SMS Delegate MFMessageComposeViewDelegate
    func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult) {
        //... handle sms screen actions
        self.dismiss(animated: true, completion: nil)
    }
    
    func reloadData() {

        let fullName = editContact?.fullName
        contactName.text = fullName
        self.isContactFavourted = editContact?.favorite ?? true

        if self.isContactFavourted {
            favouriteButtonImageView.image = UIImage.init(named: "favourite_button_selected")
        } else {
            favouriteButtonImageView.image = UIImage.init(named: "favourite_button")
        }

        phoneNumberLabel.text = editContact?.phoneNumber ?? ""
        emailLabel.text = editContact?.email ?? ""

        guard let url = URL.init(string: String(format: "%@%@", Server.DOMAIN, (editContact?.profilePic)!)) else {
            contactPhotoView.image = UIImage.init(named: "placeholder_photo")
            return
        }
        
        contactPhotoView.kf.setImage(with: url, options: [
            .transition(.fade(1)),
            .cacheOriginalImage
            ])
    }

}
