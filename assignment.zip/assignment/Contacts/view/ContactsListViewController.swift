//
//  ViewController.swift
//  Contacts
//
//  Created by admin on 29/01/19.
//  Copyright © 2019 GoJek. All rights reserved.
//

import UIKit
import Kingfisher

class ContactsListViewController: BaseVC, UITableViewDataSource, UITableViewDelegate, UISearchBarDelegate {
    
    @IBOutlet weak var contactsListTableView: UITableView!
    @IBOutlet weak var searchBar:UISearchBar!
    
    var contactListSections: [ContactListSection] = []
    var contacts:[JContact] = []
    
    var selectedContactURL: String?

    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.title = "Contacts"
        
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(title: "Group", style: .done, target: self, action: #selector(GroupTapped))

        let addContactBarButton = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(AddContactTapped))
        self.navigationItem.rightBarButtonItem = addContactBarButton
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        searchBar.resignFirstResponder()
        fetchContacts()
    }
    
    //  MARK:   -   Load Data from Web Server
    func fetchContacts() {
        HttpMgr.shared.get(url: Server.CONTACT_URL) { (data) in
            
            let decoder = JSONDecoder.init()
            decoder.keyDecodingStrategy = .convertFromSnakeCase
            
            do {
                self.contacts =  try decoder.decode([JContact].self, from: data)
                self.addingContactInSections(myContacts: self.contacts)
            } catch {
                Common.Log(str: error.localizedDescription)
            }
        }
    }
    
    //  MARK:   -   adding contacts into section
    func addingContactInSections(myContacts:[JContact]) {
        
        let sortedContacts = myContacts.sorted(by: { $0.fullName < $1.fullName })
        
        self.contactListSections = []
        
        let sectionTitles = UILocalizedIndexedCollation.current().sectionTitles
        
        var calicutaingSections: [ContactListSection] = []
        
        for title in sectionTitles {
            let contacts = sortedContacts.filter({ $0.fullName.capitalized.hasPrefix(title)})
            let section = ContactListSection.init(sectionTitle: title, contacts: contacts)
            calicutaingSections.append(section)
        }
        self.contactListSections = calicutaingSections
        
        DispatchQueue.main.async {
            self.contactsListTableView.reloadData()
        }
    }
    
    //  MARK:   -   Navigation bar left button 'Group'
    @objc func GroupTapped() {
        
    }
    
    //  MARK:   -   Navigation bar right button 'Add Contact'
    @objc func AddContactTapped() {        
        let vc = self.storyboard!.instantiateViewController(withIdentifier:"ContactAddViewController") as? ContactAddViewController
        //vc?.location = self.location
        self.navigationController!.pushViewController(vc!, animated: true)
    }
    
    //  MARK:   -   Searchbar delegate
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        //searchBar.resignFirstResponder()
        print("searchText \(searchText)")
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        print("searchText \(String(describing: searchBar.text))")
        searchBar.resignFirstResponder()
        if let keywords = searchBar.text {
            if keywords.count > 0 {
                // high order function e.g sort, map, filter, reduce here i 've used filter to bring start with result from title
                let searchResults = SearchParser.getByName(keyword: keywords, model: self.contacts)
                if searchResults.count > 0 {
                    Common.Log(str: searchResults.description)
                    self.addingContactInSections(myContacts: searchResults)
                }
                else {
                    self.showAlert(msg: "Sorry, your search keyword not found in contact db")
                }
            }
            else {
                //  normal to get all data from original contact collection
                self.addingContactInSections(myContacts: self.contacts)
            }
        }
    }
    
    //  MARK:   -   Tableview delegate
    func numberOfSections(in tableView: UITableView) -> Int {
        return contactListSections.count
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return contactListSections[section].contacts.count
    }

    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if contactListSections[section].contacts.count == 0 {
            return nil
        }
        return contactListSections[section].sectionTitle
    }

    func sectionIndexTitles(for tableView: UITableView) -> [String]? {
        return contactListSections.compactMap({ $0.sectionTitle })
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let data = contactListSections[indexPath.section].contacts[indexPath.row]

        selectedContactURL = data.url
        performSegue(withIdentifier: "viewContact", sender: nil)
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "contactCell") as! ContactCell
    
        let contact = contactListSections[indexPath.section].contacts[indexPath.row]
        
        if contact.favorite! && indexPath.row == 0 {
            Common.Log(str: "Found FAV")
        }
        else {
            Common.Log(str: "Not Found Fav")
        }
        
        cell.contactNameLabel.text = contact.fullName
        cell.contactFavouriteImageView.isHidden = !(contact.favorite ?? false)
        cell.contactPhotoView.image = UIImage.init(named: "placeholder_photo")

        guard let profilePic = contact.profilePic, let url = URL.init(string: Server.DOMAIN + profilePic) else {
            return cell
        }

        cell.contactPhotoView.kf.setImage(with: url, options: [
            .transition(.fade(1)),
            .cacheOriginalImage
            ])
        
        return cell
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "viewContact", let destination = segue.destination as? ContactDetailsViewController {
            destination.contactURL = selectedContactURL
        }
    }
}
