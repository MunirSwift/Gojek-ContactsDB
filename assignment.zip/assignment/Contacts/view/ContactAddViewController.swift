//
//  ContactAddViewController.swift
//  Contacts
//
//  Created by Rydus on 24/07/2019.
//  Copyright © 2019 GoJek. All rights reserved.
//

import UIKit

class ContactAddViewController: BaseVC, UINavigationControllerDelegate {

    @IBOutlet weak var viewCam:UIView!
    @IBOutlet weak var contactPhotoView: UIImageView!
    @IBOutlet weak var btnCam:UIButton!
    @IBOutlet weak var fname:UITextField!
    @IBOutlet weak var lname:UITextField!
    @IBOutlet weak var mobile:UITextField!
    @IBOutlet weak var email:UITextField!
    
    var imagePicker: UIImagePickerController!
    enum ImageSource {
        case photoLibrary
        case camera
    }
    
    //  MARK:   -   Camera / Gallery clicked
    @IBAction func camClicked(_:UIButton) {
        let alert = UIAlertController(title: "Photo", message: "Please Select an Option", preferredStyle: .actionSheet)
        
        alert.addAction(UIAlertAction(title: "Gallery", style: .default , handler:{ (UIAlertAction)in
            self.selectImageFrom(.photoLibrary)
        }))
        
        alert.addAction(UIAlertAction(title: "Camera", style: .default , handler:{ (UIAlertAction)in
            self.selectImageFrom(.camera)
        }))
        
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler:{ (UIAlertAction)in}))
        
        self.present(alert, animated: true, completion: {})
    }    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        navigationItem.title = "Add Contact"
        
        self.navigationItem.leftBarButtonItem = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(CancelTapped))
        
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Done", style: .done, target: self, action: #selector(DoneTapped))
        
        //  reset photo view position as per orientation or devices OR can be done by auto layout contraint
        self.contactPhotoView.frame = CGRect(x: viewCam.frame.size.width/2 - contactPhotoView.frame.size.width/2 , y: viewCam.frame.size.height/2 - contactPhotoView.frame.size.height/2, width: contactPhotoView.frame.size.width, height: contactPhotoView.frame.size.height)
        self.btnCam.frame = CGRect(x: contactPhotoView.frame.origin.x + contactPhotoView.frame.size.width-10, y: contactPhotoView.frame.origin.y + (contactPhotoView.frame.size.height-30), width: btnCam.frame.size.width, height: btnCam.frame.size.height)
    
        /*fname.text = "Munir"
        lname.text = "Abbas"
        mobile.text = "00923112824994"
        email.text = "m7unity@gmail.com"*/
    }
    
    //  MARK:   -   Image selection by source
    func selectImageFrom(_ source: ImageSource){
        imagePicker =  UIImagePickerController()
        imagePicker.delegate = self
        switch source {
        case .camera:
            imagePicker.sourceType = .camera
        case .photoLibrary:
            imagePicker.sourceType = .photoLibrary
        }
        present(imagePicker, animated: true, completion: nil)
    }
    
    //  MARK:   -   Navigation bar left button 'Group'
    @objc func CancelTapped() {
        self.navigationController?.popViewController(animated: true)
    }
    
    //  MARK:   -   Navigation bar right button 'Add Contact'
    @objc func DoneTapped() {
        if(self.validate()) {
            let params = [
                "first_name": fname.text!,
                "last_name": lname.text!,
                "email": email.text!,
                "phone_number": mobile.text!,
                "favorite":String(false),
                ] as [String : Any]
            
            HttpMgr.shared.post(url: Server.CONTACT_ADD_URL, params: params as [String : AnyObject]) { (data) in
                
                let returnData = String(data: data, encoding: .utf8)
                Common.Log(str: returnData!)
                
                self.showAlert(msg: "Profile created successfully.")
            }
        }
    }
    
    //  MARK:   - Validate data
    func validate()->Bool {
        
        if (fname.text?.isEmpty)! {
            fname.becomeFirstResponder()
            showAlert(msg: "Missing First Name")
            return false
        }
        else if (lname.text?.isEmpty)! {
            lname.becomeFirstResponder()
            showAlert(msg: "Missing Last Name")
            return false
        }
        else if (mobile.text?.isEmpty)! {
            mobile.becomeFirstResponder()
            showAlert(msg: "Missing Mobile Number")
            return false
        }
        else if (email.text?.isEmpty)! {
            email.becomeFirstResponder()
            showAlert(msg: "Missing Email Address")
            return false
        }
        else if !Common.isValidEmail(emailStr: email.text!) {
            email.becomeFirstResponder()
            showAlert(msg: "Invalid Email Address")
            return false
        }
        
        return true
    }

}

extension ContactAddViewController: UIImagePickerControllerDelegate{
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]){
        imagePicker.dismiss(animated: true, completion: nil)
        guard let selectedImage = info[.originalImage] as? UIImage else {
            Common.Log(str: "Image not found!")
            return
        }
        contactPhotoView.image = Common.resizeImage(image: selectedImage, newWidth: 500)
        Common.circleImage(img: contactPhotoView)
    }
}

