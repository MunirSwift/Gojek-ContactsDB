//
//  BaseVC.swift
//  Contacts
//
//  Created by Rydus on 23/07/2019.
//  Copyright © 2019 GoJek. All rights reserved.
//

import UIKit

class BaseVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    //  MARK:   -   MsgBox
    func showAlert(msg:String) {
        let alert = UIAlertController(title:nil, message:msg, preferredStyle:.alert)
        alert.view.backgroundColor = .black
        alert.view.alpha = 0.6
        alert.view.layer.cornerRadius = 15
        self.navigationController?.present(alert, animated: true)
        
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 3.0) {
            alert.dismiss(animated:true)
        }
    }
}
