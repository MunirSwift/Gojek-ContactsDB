//
//  Server.swift
//  Contacts
//
//  Created by Rydus on 23/07/2019.
//  Copyright © 2019 GoJek. All rights reserved.
//

import Foundation

struct Server {
    
    //  MARK:   -   Server Info
    static let DOMAIN = "https://gojek-contacts-app.herokuapp.com"
    static let CONTACT_URL = DOMAIN + "/contacts.json"
    static let CONTACT_DETAILS_FAVORITE_URL = DOMAIN + "/contacts/#id#.json"
    
    static let CONTACT_ADD_URL = DOMAIN + "/contacts"
    static let CONTACT_EDIT_URL = DOMAIN + "/contacts/#id#.json"
    
    //  MARK:   -   Contact info
    static let EMAIL = "info@gojek.com"
    static let TEL = "00923112824994"
}
